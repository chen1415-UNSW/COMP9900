
module.exports = function (request, response, next) {
    response.render('products');

};