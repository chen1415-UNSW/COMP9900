module.exports = function (request, response, next) {

    // console.log('!!!')
    response.render('register');

};